define(['./dist/basic-writeback'], (supernova) => supernova);
